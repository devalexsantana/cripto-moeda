export function NotFound(){

    return(
        <div>
            <h1>Pagina não encontrada</h1>
        </div>
    )
}