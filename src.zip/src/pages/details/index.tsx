export function Details(){

    return(
        <div>
            <h1>Details</h1>
        </div>
    )
}